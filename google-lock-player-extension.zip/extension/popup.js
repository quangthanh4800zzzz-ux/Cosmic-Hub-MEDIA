/**
 * Google Lock Player — popup.js (v1.2)
 *
 * - Lưu video mặc định vào chrome.storage.local (máy nhớ lâu, unlimitedStorage):
 *     blob:  → đọc trong tab gốc (đúng origin) → data URL → lưu
 *     http(s)/data: → lưu nguyên bản
 * - Tốc độ phát: lưu glpSettings.speed, overlay/trang khóa nghe storage.onChanged
 *   nên chỉnh lúc nào cũng áp dụng NGAY, kể cả khi lớp khóa đang bật.
 * - Bật/tắt tự mở khi vào www.google.com (glpAutoLock, mặc định bật).
 * - Mở Player Khóa / Khóa tab này → fullscreen THẬT cả cửa sổ (background API).
 */
(function () {
  'use strict';

  var statusEl = document.getElementById('status');
  var urlInput = document.getElementById('url');
  var savedName = document.getElementById('savedName');
  var speedInput = document.getElementById('speed');
  var speedVal = document.getElementById('speedVal');
  var chipsBox = document.getElementById('chips');
  var autoInput = document.getElementById('auto');
  var activeTab = null;

  var SPEED_PRESETS = [0.5, 1, 1.5, 2, 3, 4];

  function setStatus(text, cls) {
    statusEl.textContent = text;
    statusEl.className = cls || '';
  }

  function shortUrl(u) {
    if (!u) return '';
    var s = String(u);
    if (s.length <= 46) return s;
    return s.slice(0, 30) + '…' + s.slice(-14);
  }

  function fmtSpeed(s) {
    return (Math.round(s * 100) / 100).toFixed(2) + 'x';
  }

  chrome.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    activeTab = tabs && tabs[0] ? tabs[0] : null;
  });

  /* --------------------------- Nạp thiết lập --------------------------- */

  function renderChips(active) {
    chipsBox.innerHTML = '';
    SPEED_PRESETS.forEach(function (s) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip' + (Math.abs(s - active) < 0.001 ? ' active' : '');
      b.textContent = s + 'x';
      b.addEventListener('click', function () {
        applySpeed(s, true);
      });
      chipsBox.appendChild(b);
    });
  }

  function applySpeed(speed, persist) {
    var s = Number(speed);
    if (!isFinite(s)) s = 1;
    s = Math.min(4, Math.max(0.25, s));
    speedInput.value = String(s);
    speedVal.textContent = fmtSpeed(s);
    renderChips(s);
    if (persist) {
      chrome.storage.local.set({ glpSettings: { speed: s } }).then(function () {
        setStatus('Đã áp dụng tốc độ ' + fmtSpeed(s) + ' — video đang khóa đổi ngay.', 'ok');
      });
    }
  }

  function loadConfig() {
    chrome.storage.local.get(['glpVideo', 'glpSettings', 'glpAutoLock']).then(function (cfg) {
      var v = cfg.glpVideo && cfg.glpVideo.value;
      savedName.textContent = v ? shortUrl(v) : 'chưa có — dán link phía trên';
      applySpeed(cfg.glpSettings && cfg.glpSettings.speed ? cfg.glpSettings.speed : 1, false);
      autoInput.checked = cfg.glpAutoLock !== false;
    });
  }
  loadConfig();

  /* ----------------------- Lưu video mặc định -------------------------- */

  function fetchBlobAsDataUrl(blobUrl) {
    return (async () => {
      var res = await fetch(blobUrl);
      if (!res.ok) throw new Error('fetch HTTP ' + res.status);
      var blob = await res.blob();
      if (blob.size > 400 * 1024 * 1024) throw new Error('File quá lớn (> 400MB)');
      return await new Promise(function (resolve, reject) {
        var fr = new FileReader();
        fr.onload = function () {
          resolve(String(fr.result));
        };
        fr.onerror = function () {
          reject(new Error('FileReader lỗi'));
        };
        fr.readAsDataURL(blob);
      });
    })();
  }

  function saveVideo(value, extraMsg) {
    return chrome.storage.local
      .set({ glpVideo: { kind: value.indexOf('data:') === 0 ? 'data' : 'url', value: value, savedAt: Date.now() } })
      .then(function () {
        savedName.textContent = shortUrl(value);
        setStatus(extraMsg || 'Đã lưu — đi vào www.google.com là tự phát fullscreen. 🎬', 'ok');
      });
  }

  document.getElementById('save').addEventListener('click', async function () {
    var url = (urlInput.value || '').trim();
    if (!url) {
      setStatus('Hãy dán link video trước.', 'err');
      return;
    }
    try {
      if (url.indexOf('blob:') === 0) {
        if (!activeTab || typeof activeTab.id !== 'number') {
          setStatus('Không xác định được tab để đọc blob.', 'err');
          return;
        }
        setStatus('Đang đọc & lưu bản sao blob trong tab gốc…');
        var results = await chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          func: fetchBlobAsDataUrl,
          args: [url]
        });
        var dataUrl = results && results[0] ? results[0].result : null;
        if (!dataUrl) {
          throw new Error('Blob không đọc được (trang gốc đã đóng, sai origin, hoặc blob đã hết).');
        }
        await saveVideo(dataUrl, 'Đã lưu bản sao video (máy nhớ lâu) — vào Google là tự chạy. 🎬');
        return;
      }
      if (url.indexOf('https:') === 0 || url.indexOf('http:') === 0 || url.indexOf('data:') === 0) {
        await saveVideo(url);
        return;
      }
      setStatus('Link không hợp lệ — cần blob:, http(s): hoặc data:.', 'err');
    } catch (e) {
      setStatus('Lỗi: ' + ((e && e.message) || e), 'err');
    }
  });

  document.getElementById('clear').addEventListener('click', async function () {
    await chrome.storage.local.remove('glpVideo');
    savedName.textContent = 'chưa có — dán link phía trên';
    setStatus('Đã xóa video đã nhớ.', 'ok');
  });

  /* ----------------------------- Tốc độ -------------------------------- */

  speedInput.addEventListener('input', function () {
    applySpeed(Number(speedInput.value), false);
  });
  speedInput.addEventListener('change', function () {
    applySpeed(Number(speedInput.value), true);
  });

  /* --------------------- Tự mở khi vào Google -------------------------- */

  autoInput.addEventListener('change', function () {
    chrome.storage.local.set({ glpAutoLock: autoInput.checked }).then(function () {
      setStatus(
        autoInput.checked
          ? 'Bật tự mở: vào www.google.com là khóa fullscreen ngay.'
          : 'Đã tắt tự mở — chỉ khóa khi bạn bấm nút.',
        'ok'
      );
    });
  });

  /* ------------------------ Mở / khóa ngay ----------------------------- */

  function openLockedTab() {
    chrome.tabs.create({ url: chrome.runtime.getURL('locked.html') });
    // Fullscreen THẬT cả cửa sổ ngay khi mở tab khóa.
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  document.getElementById('open').addEventListener('click', async function () {
    var cfg = await chrome.storage.local.get(['glpVideo']);
    if (!(cfg.glpVideo && cfg.glpVideo.value)) {
      setStatus('Chưa có video đã lưu — dán link rồi bấm Lưu trước.', 'err');
      return;
    }
    openLockedTab();
    setStatus('Đã mở Player Khóa. 🎬', 'ok');
  });

  document.getElementById('lock').addEventListener('click', async function () {
    if (!activeTab || typeof activeTab.id !== 'number') {
      setStatus('Không xác định được tab hiện tại.', 'err');
      return;
    }
    try {
      await chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        files: ['content.js']
      });
      await chrome.tabs.sendMessage(activeTab.id, { type: 'GLP_LOCK_NOW' });
      // Khóa tab là fullscreen THẬT luôn cả cửa sổ.
      try {
        var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
        if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
      } catch (e) {
        /* noop */
      }
      window.close();
    } catch (e) {
      setStatus('Không khóa được tab này (trang hệ thống hoặc chưa tải xong).', 'err');
    }
  });
})();
