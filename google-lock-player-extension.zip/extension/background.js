/**
 * Google Lock Player — background.js (MV3 service worker, v1.2)
 *
 * Nhiệm vụ: bật FULLSCREEN THẬT (kiểu F11) cho toàn cửa sổ Chrome
 * ngay khi lớp khóa tự mở trên www.google.com — KHÔNG cần bấm gì.
 *
 * Vì sao làm ở đây?
 *  - Fullscreen API của trang web (requestFullscreen) bắt buộc phải có
 *    "user gesture" → tự mở khi vừa vào trang sẽ bị Chrome từ chối.
 *  - chrome.windows.update({ state: 'fullscreen' }) là API của tiện ích,
 *    không cần gesture → gọi từ service worker là fullscreen ngay lập tức.
 *
 * Trạng thái cửa sổ trước khi fullscreen được lưu vào chrome.storage.session
 * để gõ "unlock" thoát khóa là khôi phục đúng trạng thái cũ.
 */
'use strict';

var PREV_STATE_KEY = 'glpPrevWindowState';

function validState(s) {
  return s === 'normal' || s === 'maximized' || s === 'minimized' || s === 'fullscreen';
}

async function getWindow(preferredWindowId) {
  if (typeof preferredWindowId === 'number') {
    try {
      return await chrome.windows.get(preferredWindowId);
    } catch (e) {
      /* tab đã đóng → dùng cửa sổ đang focus */
    }
  }
  try {
    return await chrome.windows.getLastFocused();
  } catch (e) {
    return null;
  }
}

async function enterFullscreen(preferredWindowId) {
  try {
    var win = await getWindow(preferredWindowId);
    if (!win || win.state === 'fullscreen') return;
    await chrome.storage.session.set({ glpPrevWindowState: validState(win.state) ? win.state : 'normal' });
    await chrome.windows.update(win.id, { state: 'fullscreen' });
  } catch (e) {
    /* noop */
  }
}

async function exitFullscreen(preferredWindowId) {
  try {
    var win = await getWindow(preferredWindowId);
    if (!win || win.state !== 'fullscreen') return;
    var data = await chrome.storage.session.get(PREV_STATE_KEY);
    var prev = data && data[PREV_STATE_KEY];
    if (!validState(prev) || prev === 'fullscreen') prev = 'normal';
    await chrome.windows.update(win.id, { state: prev });
  } catch (e) {
    /* noop */
  }
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg.type !== 'string') return false;
  var windowId =
    sender && sender.tab && typeof sender.tab.windowId === 'number' ? sender.tab.windowId : undefined;

  if (msg.type === 'GLP_ENTER_FULLSCREEN') {
    enterFullscreen(windowId);
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === 'GLP_EXIT_FULLSCREEN') {
    exitFullscreen(windowId);
    sendResponse({ ok: true });
    return false;
  }
  return false;
});
