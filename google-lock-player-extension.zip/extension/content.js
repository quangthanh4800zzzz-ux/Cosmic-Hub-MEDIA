/**
 * Google Lock Player — content.js (Manifest V3, v1.2)
 *
 * - KHÔNG chèn bất kỳ nút/link nào lên trang nữa.
 * - Ngay khi vào www.google.com: tự mở lớp khóa toàn màn hình
 *   → video đã lưu từ trước (chrome.storage.local) tự phát lại fullscreen;
 *   nếu trang có video blob: thì ưu tiên dùng luôn video đó.
 * - FULLSCREEN THẬT: gửi lệnh cho background service worker gọi
 *   chrome.windows.update({ state: 'fullscreen' }) — API của tiện ích,
 *   KHÔNG cần user gesture nên vào trang là toàn cửa sổ Chrome fullscreen luôn.
 *   (Fullscreen API của trang chỉ xin thêm khi có tương tác đầu tiên.)
 * - Khóa 100% chuột & bàn phím ở pha capture (trước cả trang web), ẩn con trỏ.
 * - Tốc độ phát lấy từ thiết lập của popup và cập nhật TRỰC TIẾP cả khi đang khóa.
 * - Cửa thoát ẩn: gõ "unlock" (không hiển thị ở bất kỳ đâu).
 */
(function () {
  'use strict';

  if (window.__glpLoaded) return;
  window.__glpLoaded = true;

  var SECRET = 'unlock';
  var Z_MAX = '2147483647';
  var unlockedThisPage = false;

  /* ------------------------------------------------------------------ */
  /* Helpers                                                             */
  /* ------------------------------------------------------------------ */

  function el(tag, styles, text) {
    var node = document.createElement(tag);
    if (styles) {
      for (var key in styles) {
        if (Object.prototype.hasOwnProperty.call(styles, key)) {
          try {
            node.style[key] = styles[key];
          } catch (e) {
            /* noop */
          }
        }
      }
    }
    if (text != null) node.textContent = text;
    return node;
  }

  /** Dò các video blob: hiện có trên trang (cùng origin nên phát được ngay). */
  function findBlobVideos() {
    var found = [];
    function push(src) {
      if (typeof src === 'string' && src.indexOf('blob:') === 0 && found.indexOf(src) === -1) {
        found.push(src);
      }
    }
    try {
      var videos = document.querySelectorAll('video');
      for (var i = 0; i < videos.length; i++) {
        var v = videos[i];
        push(v.currentSrc || '');
        push(v.getAttribute('src') || '');
        var sources = v.querySelectorAll('source');
        for (var j = 0; j < sources.length; j++) {
          push(sources[j].getAttribute('src') || '');
        }
      }
    } catch (e) {
      /* noop */
    }
    return found;
  }

  function normalizeSpeed(speed) {
    var s = Number(speed);
    if (!isFinite(s) || s < 0.25 || s > 4) return 1;
    return s;
  }

  /** Fullscreen THẬT cả cửa sổ Chrome (chrome.windows) — không cần gesture. */
  function enterRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  /** Khôi phục trạng thái cửa sổ trước khi fullscreen. */
  function exitRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_EXIT_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  /* ------------------------------------------------------------------ */
  /* Overlay khóa toàn màn hình                                          */
  /* ------------------------------------------------------------------ */

  function buildOverlay(videoUrl, opts) {
    var cleanups = [];
    var secretBuffer = '';
    var exited = false;
    var fullscreen = !!(opts && opts.fullscreen);
    var video = null;
    var activationRetried = false;

    var backdrop = el('div', {
      position: 'fixed',
      top: '0',
      left: '0',
      right: '0',
      bottom: '0',
      zIndex: Z_MAX,
      background: '#03060a',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '0',
      userSelect: 'none',
      WebkitUserSelect: 'none',
      MozUserSelect: 'none',
      msUserSelect: 'none',
      cursor: 'none',
      overflow: 'hidden'
    });
    backdrop.id = 'glp-lock-overlay';

    if (videoUrl) {
      video = document.createElement('video');
      video.src = videoUrl;
      video.autoplay = true;
      video.loop = true;
      video.muted = true;
      video.controls = false;
      video.setAttribute('playsinline', '');
      video.setAttribute('preload', 'auto');
      var vs = fullscreen
        ? {
            // Fullscreen thật sự: phủ kín toàn bộ viewport.
            width: '100vw',
            height: '100vh',
            objectFit: 'cover',
            pointerEvents: 'none',
            background: '#000',
            display: 'block'
          }
        : {
            maxWidth: '92vw',
            maxHeight: '74vh',
            borderRadius: '14px',
            pointerEvents: 'none',
            background: '#000',
            boxShadow: '0 25px 80px rgba(0, 0, 0, 0.85)'
          };
      for (var k in vs) {
        if (Object.prototype.hasOwnProperty.call(vs, k)) video.style[k] = vs[k];
      }
      backdrop.appendChild(video);

      // Tốc độ theo thiết lập hiện tại của popup.
      chrome.storage.local.get(['glpSettings']).then(function (cfg) {
        if (video) video.playbackRate = normalizeSpeed(cfg.glpSettings && cfg.glpSettings.speed);
      });

      // Thử bật tiếng (nếu chính sách autoplay cho phép), không thì giữ tắt tiếng.
      var p = video.play();
      if (p && typeof p.then === 'function') {
        p.then(function () {
          video.muted = false;
        }).catch(function () {
          video.muted = true;
        });
      }
    } else {
      var center = el(
        'div',
        {
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '16px',
          padding: '24px',
          textAlign: 'center'
        },
        null
      );
      var big = el('div', { fontSize: '64px', lineHeight: '1' }, '🔒');
      var msg = el(
        'div',
        {
          color: '#c8d0cb',
          fontSize: '16px',
          lineHeight: '1.7',
          maxWidth: '560px',
          whiteSpace: 'pre-line',
          fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
        },
        'Trang đã bị khóa.\n' +
          'Chưa có video nào được lưu — bấm icon tiện ích trên thanh công cụ ' +
          'để dán link video (blob:/https:/data:) rồi chỉnh tốc độ mong muốn.'
      );
      center.appendChild(big);
      center.appendChild(msg);
      backdrop.appendChild(center);
    }

    // Gợi ý cửa thoát ẩn — tự mờ dần sau 4 giây.
    var hint = el(
      'div',
      {
        position: 'fixed',
        bottom: '16px',
        left: '0',
        right: '0',
        textAlign: 'center',
        color: 'rgba(255, 255, 255, 0.5)',
        fontSize: '12px',
        zIndex: Z_MAX,
        pointerEvents: 'none',
        transition: 'opacity 1.2s ease',
        fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
      },
      'Gõ "unlock" để thoát (cửa thoát ẩn) — tốc độ video chỉnh trong popup tiện ích'
    );
    hint.id = 'glp-lock-hint';

    /* ---------------------- Chặn toàn bộ sự kiện ---------------------- */

    // Fullscreen API của trang bị từ chối khi chưa có gesture →
    // thử lại ở sự kiện tương tác ĐẦU TIÊN (chưa bị chặn là có activation rồi).
    function retryFullscreenOnActivation() {
      if (!fullscreen || activationRetried || exited) return;
      activationRetried = true;
      tryFullscreen();
      tryPointerLock();
    }

    function block(e) {
      e.preventDefault();
      if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
      else e.stopPropagation();
    }

    function onKey(e) {
      // Ghi nhận chuỗi bí mật TRƯỚC khi chặn — trang vẫn trông như bị khóa hoàn toàn.
      secretBuffer = (secretBuffer + (e.key || '')).slice(-16);
      if (secretBuffer.toLowerCase().indexOf(SECRET, secretBuffer.length - SECRET.length) !== -1) {
        exit();
        return;
      }
      retryFullscreenOnActivation();
      block(e);
    }

    function blockActivation(e) {
      retryFullscreenOnActivation();
      block(e);
    }

    var events = [
      'keydown', 'keyup', 'keypress',
      'click', 'dblclick', 'mousedown', 'mouseup', 'mousemove',
      'contextmenu', 'wheel', 'selectstart', 'dragstart', 'dragover',
      'touchstart', 'touchmove', 'touchend',
      'pointerdown', 'pointerup'
    ];
    var ACTIVATION_EVENTS = { keydown: 1, mouseup: 1, pointerup: 1, touchend: 1, click: 1 };
    var opts2 = { capture: true, passive: false };

    events.forEach(function (type) {
      var handler =
        type === 'keydown' ? onKey : ACTIVATION_EVENTS[type] ? blockActivation : block;
      window.addEventListener(type, handler, opts2);
      document.addEventListener(type, handler, opts2);
      cleanups.push(function () {
        window.removeEventListener(type, handler, opts2);
        document.removeEventListener(type, handler, opts2);
      });
    });

    var prevHtmlOverflow = document.documentElement.style.overflow;
    var prevBodyOverflow = document.body.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    cleanups.push(function () {
      document.documentElement.style.overflow = prevHtmlOverflow;
      document.body.style.overflow = prevBodyOverflow;
    });

    // Cập nhật tốc độ TRỰC TIẾP khi người dùng chỉnh trong popup (kể cả đang khóa).
    function onStorageChanged(changes, area) {
      if (area !== 'local' || !video) return;
      if (changes.glpSettings && changes.glpSettings.newValue) {
        video.playbackRate = normalizeSpeed(changes.glpSettings.newValue.speed);
      }
    }
    try {
      chrome.storage.onChanged.addListener(onStorageChanged);
      cleanups.push(function () {
        chrome.storage.onChanged.removeListener(onStorageChanged);
      });
    } catch (e) {
      /* noop */
    }

    /* ------------------ Fullscreen + khóa con trỏ chuột ------------------ */

    function tryFullscreen() {
      try {
        var req = backdrop.requestFullscreen || document.documentElement.requestFullscreen;
        if (req) {
          var r = req.call(backdrop || document.documentElement);
          if (r && typeof r.catch === 'function') r.catch(function () {
            /* không có gesture → đã phủ kín viewport bằng CSS sẵn rồi */
          });
        }
      } catch (e) {
        /* noop */
      }
    }

    function tryPointerLock() {
      try {
        if (backdrop.requestPointerLock) {
          var r = backdrop.requestPointerLock();
          if (r && typeof r.catch === 'function') r.catch(function () {
            /* không có gesture → bỏ qua, con trỏ đã bị ẩn bằng CSS */
          });
        }
      } catch (e) {
        /* noop */
      }
    }

    if (fullscreen) {
      // Fullscreen THẬT cả cửa sổ qua background (không cần bấm gì).
      enterRealFullscreen();
      // Kèm Fullscreen API của trang (chỉ thành công khi có gesture —
      // nếu bị từ chối thì retry ở lần tương tác đầu, bên trên).
      setTimeout(tryFullscreen, 60);
      setTimeout(tryPointerLock, 120);
    }

    function exit() {
      if (exited) return;
      exited = true;
      if (fullscreen) exitRealFullscreen();
      cleanups.forEach(function (fn) {
        try {
          fn();
        } catch (e) {
          /* noop */
        }
      });
      try {
        if (document.exitPointerLock) document.exitPointerLock();
      } catch (e) {
        /* noop */
      }
      try {
        if (document.fullscreenElement && document.exitFullscreen) {
          var r = document.exitFullscreen();
          if (r && typeof r.catch === 'function') r.catch(function () {});
        }
      } catch (e) {
        /* noop */
      }
      backdrop.remove();
      hint.remove();
    }

    document.documentElement.appendChild(backdrop);
    document.documentElement.appendChild(hint);
    setTimeout(function () {
      hint.style.opacity = '0';
    }, 4000);
  }

  function openLocked(url, opts) {
    if (document.getElementById('glp-lock-overlay')) return;
    buildOverlay(url || null, opts || {});
  }

  /* ------------------------------------------------------------------ */
  /* Tự mở khi vào www.google.com                                        */
  /* ------------------------------------------------------------------ */

  function showNoVideoToast() {
    var toast = el(
      'div',
      {
        position: 'fixed',
        right: '18px',
        bottom: '18px',
        zIndex: '2147483646',
        maxWidth: '320px',
        padding: '12px 16px',
        borderRadius: '12px',
        background: 'rgba(6, 20, 14, 0.92)',
        border: '1px solid rgba(16, 185, 129, 0.45)',
        color: '#d1fae5',
        fontSize: '13px',
        lineHeight: '1.55',
        fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.45)',
        transition: 'opacity 0.8s ease',
        pointerEvents: 'none'
      },
      '🔒 Google Lock Player: chưa có video nào được lưu. ' +
        'Bấm icon tiện ích để dán link — từ đó đi vào www.google.com sẽ tự phát fullscreen.'
    );
    document.documentElement.appendChild(toast);
    setTimeout(function () {
      toast.style.opacity = '0';
    }, 6000);
    setTimeout(function () {
      toast.remove();
    }, 7000);
  }

  function maybeAutoLock() {
    if (unlockedThisPage) return;
    if (document.getElementById('glp-lock-overlay')) return;

    var finish = function (cfg) {
      if (unlockedThisPage) return;
      if (cfg && cfg.glpAutoLock === false) return;

      var saved = cfg && cfg.glpVideo && cfg.glpVideo.value;
      var detected = findBlobVideos()[0] || null;

      if (saved || detected) {
        openLocked(saved || detected, { fullscreen: true });
      } else {
        showNoVideoToast();
      }
    };

    try {
      chrome.storage.local
        .get(['glpVideo', 'glpSettings', 'glpAutoLock'])
        .then(finish)
        .catch(function () {
          finish(null);
        });
    } catch (e) {
      finish(null);
    }
  }

  function init() {
    if (/(^|\.)google\.com$/.test(location.hostname)) {
      // Vào www.google.com là tự mở gần như ngay lập tức.
      setTimeout(maybeAutoLock, 250);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* Nhận lệnh khóa trực tiếp từ popup ("Khóa tab này ngay"). */
  try {
    chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
      if (msg && msg.type === 'GLP_LOCK_NOW') {
        openLocked(msg.url || null, { fullscreen: false });
        sendResponse({ ok: true });
      }
      return false;
    });
  } catch (e) {
    /* ngữ cảnh extension chưa sẵn sàng: bỏ qua */
  }
})();
