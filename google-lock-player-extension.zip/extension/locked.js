/**
 * Google Lock Player — locked.js (v1.2)
 * Trang khóa độc lập của tiện ích:
 *  - Chặn 100% chuột & bàn phím ở pha capture, ẩn con trỏ chuột.
 *  - Đọc video đã lưu từ chrome.storage.local (máy nhớ lâu) — phát phủ fullscreen.
 *  - FULLSCREEN THẬT: xin background bật chrome.windows fullscreen NGAY khi mở
 *    (không cần bấm gì), đồng thời xin Fullscreen API nếu có gesture.
 *  - Tốc độ phát theo thiết lập popup, cập nhật TRỰC TIẾP khi đổi (storage.onChanged).
 *  - Cửa thoát ẩn: gõ "unlock" → khôi phục cửa sổ + đóng tab.
 */
(function () {
  'use strict';

  var SECRET = 'unlock';
  var secretBuffer = '';
  var exited = false;

  var wrap = document.getElementById('wrap');
  var hint = document.getElementById('hint');

  function block(e) {
    e.preventDefault();
    if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
    else e.stopPropagation();
  }

  function onKey(e) {
    secretBuffer = (secretBuffer + (e.key || '')).slice(-16);
    if (secretBuffer.toLowerCase().indexOf(SECRET, secretBuffer.length - SECRET.length) !== -1) {
      exit();
      return;
    }
    block(e);
  }

  var events = [
    'keydown', 'keyup', 'keypress',
    'click', 'dblclick', 'mousedown', 'mouseup', 'mousemove',
    'contextmenu', 'wheel', 'selectstart', 'dragstart', 'dragover',
    'touchstart', 'touchmove', 'touchend',
    'pointerdown', 'pointerup'
  ];
  var opts = { capture: true, passive: false };
  events.forEach(function (type) {
    var handler = type === 'keydown' ? onKey : block;
    window.addEventListener(type, handler, opts);
    document.addEventListener(type, handler, opts);
  });

  function normalizeSpeed(speed) {
    var s = Number(speed);
    if (!isFinite(s) || s < 0.25 || s > 4) return 1;
    return s;
  }

  /** Fullscreen THẬT cả cửa sổ Chrome qua background — không cần gesture. */
  function enterRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  function exitRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_EXIT_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  function exit() {
    if (exited) return;
    exited = true;
    exitRealFullscreen();
    try {
      window.close();
    } catch (e) {
      /* noop */
    }
    setTimeout(function () {
      try {
        window.close();
      } catch (e) {
        /* noop */
      }
      // Phương án dự phòng nếu window.close() bị chặn.
      location.href = 'https://www.google.com';
    }, 200);
  }

  setTimeout(function () {
    hint.style.opacity = '0';
  }, 4000);

  /* ------------------------ Phát video (nếu có) ------------------------ */

  var video = null;

  function attachVideo(src) {
    video = document.createElement('video');
    video.src = src;
    video.autoplay = true;
    video.loop = true;
    video.muted = true;
    video.controls = false;
    video.setAttribute('playsinline', '');
    video.setAttribute('preload', 'auto');
    // Fullscreen: phủ kín toàn bộ trang.
    video.style.width = '100vw';
    video.style.height = '100vh';
    video.style.objectFit = 'cover';
    video.style.display = 'block';
    wrap.appendChild(video);

    var p = video.play();
    if (p && typeof p.then === 'function') {
      p.then(function () {
        video.muted = false;
      }).catch(function () {
        video.muted = true;
      });
    }

    // Áp tốc độ đã lưu.
    chrome.storage.local.get(['glpSettings']).then(function (cfg) {
      if (video) video.playbackRate = normalizeSpeed(cfg.glpSettings && cfg.glpSettings.speed);
    });

    // Cố gắng xin fullscreen thật (nếu có gesture, không thì CSS đã phủ kín).
    setTimeout(function () {
      try {
        var r = document.documentElement.requestFullscreen();
        if (r && typeof r.catch === 'function') r.catch(function () {});
      } catch (e) {
        /* noop */
      }
    }, 80);
  }

  // Fullscreen THẬT cả cửa sổ NGAY khi mở trang khóa (không cần bấm gì).
  enterRealFullscreen();

  function showEmptyState() {
    var icon = document.createElement('div');
    icon.className = 'icon';
    icon.textContent = '🔒';
    var msg = document.createElement('div');
    msg.className = 'msg';
    msg.textContent =
      'Chưa có video nào được lưu.\n' +
      'Bấm icon tiện ích → dán link blob:/https:/data: → "Lưu video & tự chạy trên Google".';
    wrap.appendChild(icon);
    wrap.appendChild(msg);
  }

  // Đổi tốc độ TRỰC TIẾP khi chỉnh trong popup.
  function onStorageChanged(changes, area) {
    if (area !== 'local' || !video) return;
    if (changes.glpSettings && changes.glpSettings.newValue) {
      video.playbackRate = normalizeSpeed(changes.glpSettings.newValue.speed);
    }
  }

  try {
    chrome.storage.local.get(['glpVideo']).then(function (result) {
      var data = result && result.glpVideo;
      if (data && data.value) {
        attachVideo(data.value);
      } else {
        showEmptyState();
      }
    });
    chrome.storage.onChanged.addListener(onStorageChanged);
  } catch (e) {
    showEmptyState();
  }
})();
