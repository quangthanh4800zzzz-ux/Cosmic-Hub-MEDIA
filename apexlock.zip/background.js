/**
 * Google Lock Player — background.js (MV3 service worker, v1.3)
 *
 * Purpose: turn on TRUE fullscreen (F11-style) for the whole Chrome window
 * the moment the lock layer auto-starts on ANY website — nothing to click.
 *
 * Why here?
 *  - The page-level Fullscreen API (requestFullscreen) requires a "user gesture"
 *    -> auto-starting right after page load gets rejected by Chrome.
 *  - chrome.windows.update({ state: 'fullscreen' }) is an extension API and
 *    needs no gesture -> calling it from the service worker fullscreens the
 *    window instantly (the same technique used by "Auto Fullscreen" extensions).
 *
 * The window state before fullscreen is saved in chrome.storage.session so
 * typing "unlock" restores exactly what the user had before.
 */
'use strict';

var PREV_STATE_KEY = 'glpPrevWindowState';

function validState(s) {
  return s === 'normal' || s === 'maximized' || s === 'minimized' || s === 'fullscreen';
}

async function getWindow(preferredWindowId) {
  if (typeof preferredWindowId === 'number') {
    try {
      return await chrome.windows.get(preferredWindowId);
    } catch (e) {
      /* tab already closed -> fall back to the focused window */
    }
  }
  try {
    return await chrome.windows.getLastFocused();
  } catch (e) {
    return null;
  }
}

async function enterFullscreen(preferredWindowId) {
  try {
    var win = await getWindow(preferredWindowId);
    if (!win || win.state === 'fullscreen') return;
    await chrome.storage.session.set({ glpPrevWindowState: validState(win.state) ? win.state : 'normal' });
    await chrome.windows.update(win.id, { state: 'fullscreen' });
  } catch (e) {
    /* noop */
  }
}

async function exitFullscreen(preferredWindowId) {
  try {
    var win = await getWindow(preferredWindowId);
    if (!win || win.state !== 'fullscreen') return;
    var data = await chrome.storage.session.get(PREV_STATE_KEY);
    var prev = data && data[PREV_STATE_KEY];
    if (!validState(prev) || prev === 'fullscreen') prev = 'normal';
    await chrome.windows.update(win.id, { state: prev });
  } catch (e) {
    /* noop */
  }
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || typeof msg.type !== 'string') return false;
  var windowId =
    sender && sender.tab && typeof sender.tab.windowId === 'number' ? sender.tab.windowId : undefined;

  if (msg.type === 'GLP_ENTER_FULLSCREEN') {
    enterFullscreen(windowId);
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === 'GLP_EXIT_FULLSCREEN') {
    exitFullscreen(windowId);
    sendResponse({ ok: true });
    return false;
  }
  return false;
});
