/**
 * Google Lock Player — popup.js (v1.3)
 *
 * - Saves the default video into chrome.storage.local (remembered on this machine,
 *   unlimitedStorage):
 *     blob:  -> read in the origin tab (same origin) -> data URL -> saved
 *     http(s)/data: -> stored as-is
 * - Playback speed: stored as glpSettings.speed; the lock layer / lock page listen
 *   to storage.onChanged, so changes apply INSTANTLY, even while locked.
 * - Toggle auto-open on every website (glpAutoLock, on by default).
 * - Open Lock Player / Lock this tab -> TRUE whole-window fullscreen (background API).
 */
(function () {
  'use strict';

  var statusEl = document.getElementById('status');
  var urlInput = document.getElementById('url');
  var savedName = document.getElementById('savedName');
  var speedInput = document.getElementById('speed');
  var speedVal = document.getElementById('speedVal');
  var chipsBox = document.getElementById('chips');
  var autoInput = document.getElementById('auto');
  var activeTab = null;

  var SPEED_PRESETS = [0.5, 1, 1.5, 2, 3, 4];

  function setStatus(text, cls) {
    statusEl.textContent = text;
    statusEl.className = cls || '';
  }

  function shortUrl(u) {
    if (!u) return '';
    var s = String(u);
    if (s.length <= 46) return s;
    return s.slice(0, 30) + '…' + s.slice(-14);
  }

  function fmtSpeed(s) {
    return (Math.round(s * 100) / 100).toFixed(2) + 'x';
  }

  chrome.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    activeTab = tabs && tabs[0] ? tabs[0] : null;
  });

  /* --------------------------- Nạp thiết lập --------------------------- */

  function renderChips(active) {
    chipsBox.innerHTML = '';
    SPEED_PRESETS.forEach(function (s) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip' + (Math.abs(s - active) < 0.001 ? ' active' : '');
      b.textContent = s + 'x';
      b.addEventListener('click', function () {
        applySpeed(s, true);
      });
      chipsBox.appendChild(b);
    });
  }

  function applySpeed(speed, persist) {
    var s = Number(speed);
    if (!isFinite(s)) s = 1;
    s = Math.min(4, Math.max(0.25, s));
    speedInput.value = String(s);
    speedVal.textContent = fmtSpeed(s);
    renderChips(s);
    if (persist) {
      chrome.storage.local.set({ glpSettings: { speed: s } }).then(function () {
        setStatus('Speed ' + fmtSpeed(s) + ' applied — the locked video changes instantly.', 'ok');
      });
    }
  }

  function loadConfig() {
    chrome.storage.local.get(['glpVideo', 'glpSettings', 'glpAutoLock']).then(function (cfg) {
      var v = cfg.glpVideo && cfg.glpVideo.value;
      savedName.textContent = v ? shortUrl(v) : 'none yet — paste a link above';
      applySpeed(cfg.glpSettings && cfg.glpSettings.speed ? cfg.glpSettings.speed : 1, false);
      autoInput.checked = cfg.glpAutoLock !== false;
    });
  }
  loadConfig();

  /* ----------------------- Save default video -------------------------- */

  function fetchBlobAsDataUrl(blobUrl) {
    return (async () => {
      var res = await fetch(blobUrl);
      if (!res.ok) throw new Error('fetch HTTP ' + res.status);
      var blob = await res.blob();
      if (blob.size > 400 * 1024 * 1024) throw new Error('File too large (> 400MB)');
      return await new Promise(function (resolve, reject) {
        var fr = new FileReader();
        fr.onload = function () {
          resolve(String(fr.result));
        };
        fr.onerror = function () {
          reject(new Error('FileReader failed'));
        };
        fr.readAsDataURL(blob);
      });
    })();
  }

  function saveVideo(value, extraMsg) {
    return chrome.storage.local
      .set({ glpVideo: { kind: value.indexOf('data:') === 0 ? 'data' : 'url', value: value, savedAt: Date.now() } })
      .then(function () {
        savedName.textContent = shortUrl(value);
        setStatus(extraMsg || 'Saved — every website you open now starts fullscreen with this video.', 'ok');
      });
  }

  document.getElementById('save').addEventListener('click', async function () {
    var url = (urlInput.value || '').trim();
    if (!url) {
      setStatus('Paste a video link first.', 'err');
      return;
    }
    try {
      if (url.indexOf('blob:') === 0) {
        if (!activeTab || typeof activeTab.id !== 'number') {
          setStatus('Could not determine the tab to read the blob from.', 'err');
          return;
        }
        setStatus('Reading & saving a blob copy in the origin tab…');
        var results = await chrome.scripting.executeScript({
          target: { tabId: activeTab.id },
          func: fetchBlobAsDataUrl,
          args: [url]
        });
        var dataUrl = results && results[0] ? results[0].result : null;
        if (!dataUrl) {
          throw new Error('Blob unreadable (origin tab closed, wrong origin, or the blob expired).');
        }
        await saveVideo(dataUrl, 'Saved a permanent copy of the video — every site auto-plays it.');
        return;
      }
      if (url.indexOf('https:') === 0 || url.indexOf('http:') === 0 || url.indexOf('data:') === 0) {
        await saveVideo(url);
        return;
      }
      setStatus('Invalid link — needs blob:, http(s): or data:.', 'err');
    } catch (e) {
      setStatus('Error: ' + ((e && e.message) || e), 'err');
    }
  });

  document.getElementById('clear').addEventListener('click', async function () {
    await chrome.storage.local.remove('glpVideo');
    savedName.textContent = 'none yet — paste a link above';
    setStatus('Saved video removed.', 'ok');
  });

  /* --------------------------- Speed ----------------------------------- */

  speedInput.addEventListener('input', function () {
    applySpeed(Number(speedInput.value), false);
  });
  speedInput.addEventListener('change', function () {
    applySpeed(Number(speedInput.value), true);
  });

  /* --------------------- Auto-open everywhere -------------------------- */

  autoInput.addEventListener('change', function () {
    chrome.storage.local.set({ glpAutoLock: autoInput.checked }).then(function () {
      setStatus(
        autoInput.checked
          ? 'Auto-open ON: every website you open starts fullscreen + locked.'
          : 'Auto-open OFF — the lock only starts when you press a button.',
        'ok'
      );
    });
  });

  /* ------------------------ Open / lock now ----------------------------- */

  function openLockedTab() {
    chrome.tabs.create({ url: chrome.runtime.getURL('locked.html') });
    // TRUE whole-window fullscreen right when the lock tab opens.
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  document.getElementById('open').addEventListener('click', async function () {
    var cfg = await chrome.storage.local.get(['glpVideo']);
    if (!(cfg.glpVideo && cfg.glpVideo.value)) {
      setStatus('No saved video yet — paste a link and press Save first.', 'err');
      return;
    }
    openLockedTab();
    setStatus('Lock Player opened.', 'ok');
  });

  document.getElementById('lock').addEventListener('click', async function () {
    if (!activeTab || typeof activeTab.id !== 'number') {
      setStatus('Could not determine the current tab.', 'err');
      return;
    }
    try {
      await chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        files: ['content.js']
      });
      await chrome.tabs.sendMessage(activeTab.id, { type: 'GLP_LOCK_NOW' });
      // Locking the tab also flips TRUE fullscreen for the whole window.
      try {
        var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
        if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
      } catch (e) {
        /* noop */
      }
      window.close();
    } catch (e) {
      setStatus('Cannot lock this tab (browser page or still loading).', 'err');
    }
  });
})();
