/**
 * Google Lock Player — content.js (Manifest V3, v1.3)
 *
 * - NO button/link is injected into any page anymore.
 * - Works on EVERY website (manifest matches <all_urls>):
 *   the moment a page opens, the fullscreen lock layer auto-starts
 *   -> your previously saved video (chrome.storage.local) replays fullscreen;
 *   if the page itself contains blob: videos, they are used first.
 * - TRUE FULLSCREEN: asks the background service worker to call
 *   chrome.windows.update({ state: 'fullscreen' }) — an extension API that
 *   needs NO user gesture, so the whole Chrome window goes fullscreen instantly.
 *   (The page-level Fullscreen API is also retried on the first interaction.)
 * - Blocks 100% of mouse & keyboard events in the capture phase (before the page),
 *   hides the cursor.
 * - Playback speed comes from the popup settings and updates LIVE even while locked.
 * - Hidden exit: type "unlock" (never displayed anywhere).
 */
(function () {
  'use strict';

  if (window.__glpLoaded) return;
  window.__glpLoaded = true;

  var SECRET = 'unlock';
  var Z_MAX = '2147483647';
  var unlockedThisPage = false;

  /* ------------------------------------------------------------------ */
  /* Helpers                                                             */
  /* ------------------------------------------------------------------ */

  function el(tag, styles, text) {
    var node = document.createElement(tag);
    if (styles) {
      for (var key in styles) {
        if (Object.prototype.hasOwnProperty.call(styles, key)) {
          try {
            node.style[key] = styles[key];
          } catch (e) {
            /* noop */
          }
        }
      }
    }
    if (text != null) node.textContent = text;
    return node;
  }

  /** Detect blob: videos already present on this page (same origin -> plays instantly). */
  function findBlobVideos() {
    var found = [];
    function push(src) {
      if (typeof src === 'string' && src.indexOf('blob:') === 0 && found.indexOf(src) === -1) {
        found.push(src);
      }
    }
    try {
      var videos = document.querySelectorAll('video');
      for (var i = 0; i < videos.length; i++) {
        var v = videos[i];
        push(v.currentSrc || '');
        push(v.getAttribute('src') || '');
        var sources = v.querySelectorAll('source');
        for (var j = 0; j < sources.length; j++) {
          push(sources[j].getAttribute('src') || '');
        }
      }
    } catch (e) {
      /* noop */
    }
    return found;
  }

  function normalizeSpeed(speed) {
    var s = Number(speed);
    if (!isFinite(s) || s < 0.25 || s > 4) return 1;
    return s;
  }

  /** TRUE fullscreen of the whole Chrome window (chrome.windows) — no gesture needed. */
  function enterRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  /** Restores the window state that was active before fullscreen. */
  function exitRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_EXIT_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  /* ------------------------------------------------------------------ */
  /* Fullscreen lock overlay                                             */
  /* ------------------------------------------------------------------ */

  function buildOverlay(videoUrl, opts) {
    var cleanups = [];
    var secretBuffer = '';
    var exited = false;
    var fullscreen = !!(opts && opts.fullscreen);
    var video = null;
    var activationRetried = false;

    var backdrop = el('div', {
      position: 'fixed',
      top: '0',
      left: '0',
      right: '0',
      bottom: '0',
      zIndex: Z_MAX,
      background: '#03060a',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '0',
      userSelect: 'none',
      WebkitUserSelect: 'none',
      MozUserSelect: 'none',
      msUserSelect: 'none',
      cursor: 'none',
      overflow: 'hidden'
    });
    backdrop.id = 'glp-lock-overlay';

    if (videoUrl) {
      video = document.createElement('video');
      video.src = videoUrl;
      video.autoplay = true;
      video.loop = true;
      video.muted = true;
      video.controls = false;
      video.setAttribute('playsinline', '');
      video.setAttribute('preload', 'auto');
      var vs = fullscreen
        ? {
            // True fullscreen: cover the entire viewport.
            width: '100vw',
            height: '100vh',
            objectFit: 'cover',
            pointerEvents: 'none',
            background: '#000',
            display: 'block'
          }
        : {
            maxWidth: '92vw',
            maxHeight: '74vh',
            borderRadius: '14px',
            pointerEvents: 'none',
            background: '#000',
            boxShadow: '0 25px 80px rgba(0, 0, 0, 0.85)'
          };
      for (var k in vs) {
        if (Object.prototype.hasOwnProperty.call(vs, k)) video.style[k] = vs[k];
      }
      backdrop.appendChild(video);

      // Speed follows the current popup setting.
      chrome.storage.local.get(['glpSettings']).then(function (cfg) {
        if (video) video.playbackRate = normalizeSpeed(cfg.glpSettings && cfg.glpSettings.speed);
      });

      // Try to unmute (if the autoplay policy allows), otherwise stay muted.
      var p = video.play();
      if (p && typeof p.then === 'function') {
        p.then(function () {
          video.muted = false;
        }).catch(function () {
          video.muted = true;
        });
      }
    } else {
      var center = el(
        'div',
        {
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '16px',
          padding: '24px',
          textAlign: 'center'
        },
        null
      );
      var big = el(
        'div',
        {
          color: '#e5e7eb',
          fontSize: '28px',
          fontWeight: '700',
          letterSpacing: '4px',
          textTransform: 'uppercase',
          fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
        },
        'Apex Lock'
      );
      var msg = el(
        'div',
        {
          color: '#c8d0cb',
          fontSize: '16px',
          lineHeight: '1.7',
          maxWidth: '560px',
          whiteSpace: 'pre-line',
          fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
        },
        'This page is locked.\n' +
          'No video has been saved yet — click the extension icon in the toolbar ' +
          'to paste a video link (blob:/https:/data:) and pick your playback speed.'
      );
      center.appendChild(big);
      center.appendChild(msg);
      backdrop.appendChild(center);
    }

    // Hidden-exit hint — fades out after 4 seconds.
    var hint = el(
      'div',
      {
        position: 'fixed',
        bottom: '16px',
        left: '0',
        right: '0',
        textAlign: 'center',
        color: 'rgba(255, 255, 255, 0.5)',
        fontSize: '12px',
        zIndex: Z_MAX,
        pointerEvents: 'none',
        transition: 'opacity 1.2s ease',
        fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'
      },
      'Type "unlock" to exit (hidden exit) — video speed is set in the extension popup'
    );
    hint.id = 'glp-lock-hint';

    /* ---------------------- Block every event ---------------------- */

    // The page-level Fullscreen API is rejected without a user gesture ->
    // retry on the FIRST interaction event (activation exists by then).
    function retryFullscreenOnActivation() {
      if (!fullscreen || activationRetried || exited) return;
      activationRetried = true;
      tryFullscreen();
      tryPointerLock();
    }

    function block(e) {
      e.preventDefault();
      if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
      else e.stopPropagation();
    }

    function onKey(e) {
      // Record the secret string BEFORE blocking — the page still looks fully locked.
      secretBuffer = (secretBuffer + (e.key || '')).slice(-16);
      if (secretBuffer.toLowerCase().indexOf(SECRET, secretBuffer.length - SECRET.length) !== -1) {
        exit();
        return;
      }
      retryFullscreenOnActivation();
      block(e);
    }

    function blockActivation(e) {
      retryFullscreenOnActivation();
      block(e);
    }

    var events = [
      'keydown', 'keyup', 'keypress',
      'click', 'dblclick', 'mousedown', 'mouseup', 'mousemove',
      'contextmenu', 'wheel', 'selectstart', 'dragstart', 'dragover',
      'touchstart', 'touchmove', 'touchend',
      'pointerdown', 'pointerup'
    ];
    var ACTIVATION_EVENTS = { keydown: 1, mouseup: 1, pointerup: 1, touchend: 1, click: 1 };
    var opts2 = { capture: true, passive: false };

    events.forEach(function (type) {
      var handler =
        type === 'keydown' ? onKey : ACTIVATION_EVENTS[type] ? blockActivation : block;
      window.addEventListener(type, handler, opts2);
      document.addEventListener(type, handler, opts2);
      cleanups.push(function () {
        window.removeEventListener(type, handler, opts2);
        document.removeEventListener(type, handler, opts2);
      });
    });

    var prevHtmlOverflow = document.documentElement.style.overflow;
    var prevBodyOverflow = document.body.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    cleanups.push(function () {
      document.documentElement.style.overflow = prevHtmlOverflow;
      document.body.style.overflow = prevBodyOverflow;
    });

    // Update the speed LIVE when the user changes it in the popup (even while locked).
    function onStorageChanged(changes, area) {
      if (area !== 'local' || !video) return;
      if (changes.glpSettings && changes.glpSettings.newValue) {
        video.playbackRate = normalizeSpeed(changes.glpSettings.newValue.speed);
      }
    }
    try {
      chrome.storage.onChanged.addListener(onStorageChanged);
      cleanups.push(function () {
        chrome.storage.onChanged.removeListener(onStorageChanged);
      });
    } catch (e) {
      /* noop */
    }

    /* ------------------ Fullscreen + pointer lock ------------------ */

    function tryFullscreen() {
      try {
        var req = backdrop.requestFullscreen || document.documentElement.requestFullscreen;
        if (req) {
          var r = req.call(backdrop || document.documentElement);
          if (r && typeof r.catch === 'function') r.catch(function () {
            /* no gesture yet -> the CSS layer already covers the viewport */
          });
        }
      } catch (e) {
        /* noop */
      }
    }

    function tryPointerLock() {
      try {
        if (backdrop.requestPointerLock) {
          var r = backdrop.requestPointerLock();
          if (r && typeof r.catch === 'function') r.catch(function () {
            /* no gesture yet -> the cursor is already hidden via CSS */
          });
        }
      } catch (e) {
        /* noop */
      }
    }

    if (fullscreen) {
      // TRUE window fullscreen via the background worker (no click required).
      enterRealFullscreen();
      // Plus the page-level Fullscreen API (only succeeds with a gesture —
      // if rejected it is retried on the first interaction, see above).
      setTimeout(tryFullscreen, 60);
      setTimeout(tryPointerLock, 120);
    }

    function exit() {
      if (exited) return;
      exited = true;
      if (fullscreen) exitRealFullscreen();
      cleanups.forEach(function (fn) {
        try {
          fn();
        } catch (e) {
          /* noop */
        }
      });
      try {
        if (document.exitPointerLock) document.exitPointerLock();
      } catch (e) {
        /* noop */
      }
      try {
        if (document.fullscreenElement && document.exitFullscreen) {
          var r = document.exitFullscreen();
          if (r && typeof r.catch === 'function') r.catch(function () {});
        }
      } catch (e) {
        /* noop */
      }
      backdrop.remove();
      hint.remove();
    }

    document.documentElement.appendChild(backdrop);
    document.documentElement.appendChild(hint);
    setTimeout(function () {
      hint.style.opacity = '0';
    }, 4000);
  }

  function openLocked(url, opts) {
    if (document.getElementById('glp-lock-overlay')) return;
    buildOverlay(url || null, opts || {});
  }

  /* ------------------------------------------------------------------ */
  /* Auto-start on EVERY website                                         */
  /* ------------------------------------------------------------------ */

  /**
   * Shown at most ONCE per browser session (chrome.storage.session) so that
   * browsing without a saved video never gets spammed with toasts.
   */
  function showNoVideoToastOnce() {
    var done = function () {
      var toast = el(
        'div',
        {
          position: 'fixed',
          right: '18px',
          bottom: '18px',
          zIndex: '2147483646',
          maxWidth: '320px',
          padding: '12px 16px',
          borderRadius: '12px',
          background: 'rgba(6, 20, 14, 0.92)',
          border: '1px solid rgba(16, 185, 129, 0.45)',
          color: '#d1fae5',
          fontSize: '13px',
          lineHeight: '1.55',
          fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
          boxShadow: '0 10px 30px rgba(0, 0, 0, 0.45)',
          transition: 'opacity 0.8s ease',
          pointerEvents: 'none'
        },
        'Apex Lock: no video saved yet. ' +
          'Click the extension icon to paste a link — from then on every website you open starts fullscreen with your video.'
      );
      document.documentElement.appendChild(toast);
      setTimeout(function () {
        toast.style.opacity = '0';
      }, 6000);
      setTimeout(function () {
        toast.remove();
      }, 7000);
    };
    try {
      chrome.storage.session.get(['glpHintShown']).then(function (res) {
        if (res && res.glpHintShown) return;
        chrome.storage.session.set({ glpHintShown: true }).then(done, done);
      }).catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  function maybeAutoLock() {
    if (unlockedThisPage) return;
    if (document.getElementById('glp-lock-overlay')) return;

    var finish = function (cfg) {
      if (unlockedThisPage) return;
      if (cfg && cfg.glpAutoLock === false) return;

      var saved = cfg && cfg.glpVideo && cfg.glpVideo.value;
      var detected = findBlobVideos()[0] || null;

      if (saved || detected) {
        openLocked(saved || detected, { fullscreen: true });
      } else {
        showNoVideoToastOnce();
      }
    };

    try {
      chrome.storage.local
        .get(['glpVideo', 'glpSettings', 'glpAutoLock'])
        .then(finish)
        .catch(function () {
          finish(null);
        });
    } catch (e) {
      finish(null);
    }
  }

  function init() {
    // EVERY website: auto-start the lock almost immediately.
    setTimeout(maybeAutoLock, 250);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* Receive the direct lock command from the popup ("Lock this tab now"). */
  try {
    chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
      if (msg && msg.type === 'GLP_LOCK_NOW') {
        openLocked(msg.url || null, { fullscreen: false });
        sendResponse({ ok: true });
      }
      return false;
    });
  } catch (e) {
    /* extension context not ready yet: ignore */
  }
})();
