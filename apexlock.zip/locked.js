/**
 * Google Lock Player — locked.js (v1.3)
 * The extension's standalone lock page:
 *  - Blocks 100% of mouse & keyboard in the capture phase, hides the cursor.
 *  - Reads the saved video from chrome.storage.local (remembered on this machine)
 *    and plays it covering the whole screen.
 *  - TRUE FULLSCREEN: asks the background to flip chrome.windows fullscreen the
 *    moment the page opens (no click needed), plus the page-level Fullscreen API
 *    whenever a gesture is available.
 *  - Playback speed follows the popup setting and updates LIVE (storage.onChanged).
 *  - Hidden exit: type "unlock" -> restore the window + close the tab.
 */
(function () {
  'use strict';

  var SECRET = 'unlock';
  var secretBuffer = '';
  var exited = false;

  var wrap = document.getElementById('wrap');
  var hint = document.getElementById('hint');

  function block(e) {
    e.preventDefault();
    if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
    else e.stopPropagation();
  }

  function onKey(e) {
    secretBuffer = (secretBuffer + (e.key || '')).slice(-16);
    if (secretBuffer.toLowerCase().indexOf(SECRET, secretBuffer.length - SECRET.length) !== -1) {
      exit();
      return;
    }
    block(e);
  }

  var events = [
    'keydown', 'keyup', 'keypress',
    'click', 'dblclick', 'mousedown', 'mouseup', 'mousemove',
    'contextmenu', 'wheel', 'selectstart', 'dragstart', 'dragover',
    'touchstart', 'touchmove', 'touchend',
    'pointerdown', 'pointerup'
  ];
  var opts = { capture: true, passive: false };
  events.forEach(function (type) {
    var handler = type === 'keydown' ? onKey : block;
    window.addEventListener(type, handler, opts);
    document.addEventListener(type, handler, opts);
  });

  function normalizeSpeed(speed) {
    var s = Number(speed);
    if (!isFinite(s) || s < 0.25 || s > 4) return 1;
    return s;
  }

  /** TRUE fullscreen of the whole Chrome window via the background — no gesture needed. */
  function enterRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_ENTER_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  function exitRealFullscreen() {
    try {
      var p = chrome.runtime.sendMessage({ type: 'GLP_EXIT_FULLSCREEN' });
      if (p && typeof p.catch === 'function') p.catch(function () { /* noop */ });
    } catch (e) {
      /* noop */
    }
  }

  function exit() {
    if (exited) return;
    exited = true;
    exitRealFullscreen();
    try {
      window.close();
    } catch (e) {
      /* noop */
    }
    setTimeout(function () {
      try {
        window.close();
      } catch (e) {
        /* noop */
      }
      // Fallback if window.close() is blocked.
      location.href = 'about:blank';
    }, 200);
  }

  setTimeout(function () {
    hint.style.opacity = '0';
  }, 4000);

  /* ------------------------ Phát video (nếu có) ------------------------ */

  var video = null;

  function attachVideo(src) {
    video = document.createElement('video');
    video.src = src;
    video.autoplay = true;
    video.loop = true;
    video.muted = true;
    video.controls = false;
    video.setAttribute('playsinline', '');
    video.setAttribute('preload', 'auto');
    // Cover the whole page (true fullscreen style).
    video.style.width = '100vw';
    video.style.height = '100vh';
    video.style.objectFit = 'cover';
    video.style.display = 'block';
    wrap.appendChild(video);

    var p = video.play();
    if (p && typeof p.then === 'function') {
      p.then(function () {
        video.muted = false;
      }).catch(function () {
        video.muted = true;
      });
    }

    // Apply the saved speed.
    chrome.storage.local.get(['glpSettings']).then(function (cfg) {
      if (video) video.playbackRate = normalizeSpeed(cfg.glpSettings && cfg.glpSettings.speed);
    });

    // Ask for the page-level fullscreen too (works with a gesture, otherwise the CSS already covers everything).
    setTimeout(function () {
      try {
        var r = document.documentElement.requestFullscreen();
        if (r && typeof r.catch === 'function') r.catch(function () {});
      } catch (e) {
        /* noop */
      }
    }, 80);
  }

  // TRUE whole-window fullscreen RIGHT when the lock page opens (no click needed).
  enterRealFullscreen();

  function showEmptyState() {
    var icon = document.createElement('div');
    icon.className = 'icon';
    icon.textContent = 'APEX LOCK';
    icon.style.fontSize = '22px';
    icon.style.fontWeight = '700';
    icon.style.letterSpacing = '4px';
    icon.style.textTransform = 'uppercase';
    var msg = document.createElement('div');
    msg.className = 'msg';
    msg.textContent =
      'No video has been saved yet.\n' +
      'Click the extension icon, paste a blob:/https:/data: link, then press "Save".';
    wrap.appendChild(icon);
    wrap.appendChild(msg);
  }

  // Update the speed LIVE while the user changes it in the popup.
  function onStorageChanged(changes, area) {
    if (area !== 'local' || !video) return;
    if (changes.glpSettings && changes.glpSettings.newValue) {
      video.playbackRate = normalizeSpeed(changes.glpSettings.newValue.speed);
    }
  }

  try {
    chrome.storage.local.get(['glpVideo']).then(function (result) {
      var data = result && result.glpVideo;
      if (data && data.value) {
        attachVideo(data.value);
      } else {
        showEmptyState();
      }
    });
    chrome.storage.onChanged.addListener(onStorageChanged);
  } catch (e) {
    showEmptyState();
  }
})();
